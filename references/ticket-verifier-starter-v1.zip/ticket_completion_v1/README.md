# Can an agent close this ticket?

This starter corpus teaches a verifier to read a ticket and the available tool records, return a verdict, and cite the lines supporting it. All records are fictional. This folder contains the data itself, a reproducible generator, a scorer, and an optional experiment for choosing when to use extended reasoning.

## Start here

1. Open `first_look.csv` in a spreadsheet. Hide the last three columns, read a ticket and its records, and decide whether you would close it. Reveal the verdict, evidence, and explanation. These nine examples come from training.
2. Run your **original model** on `eval/dev/prompts.jsonl`. Send only the conversation in `prompt`. Keep the row ID beside the response. Use separate conversations for each ticket.
3. Train a copy of the model on **`data/train.jsonl`**. Each line contains a user message and the desired assistant reply. In a working Halo SFT recipe for your model, replace its dataset with the file path as seen inside the training container. Keep the model's own chat template and its matching assistant marker. The relevant settings are below.
4. Score the original and adapted model on the same development prompts with the same decoding settings. Use `eval/test` and `eval/challenge` for final measurements after choosing the recipe. Within every evaluation directory the prompts and answer keys are separate.

```yaml
dataset: ./data/train.jsonl
conversation_field: prompt
```

The two settings assume the extracted folder is visible as the training process's working directory. Official references: [Halo SFT](https://whitecircle.com/halo/docs/training-methods/sft) and [local dataset loading](https://whitecircle.com/halo/docs/data).

## What the labels mean

| Verdict | Evidence rule |
|---|---|
| `complete` | Reliable evidence establishes every requested final condition. A later final read can establish success after an earlier error. |
| `incomplete` | Reliable evidence contradicts at least one final condition. Even if another fact is missing, the observed contradiction settles the verdict. |
| `unverified` | The supplied records leave a required fact open and establish no contradiction. An acceptance receipt, a different target, a stale snapshot, or a partial listing may leave that gap. |

Sometimes the same incomplete listing can settle one question and leave another open. Seeing file 44 on page one establishes it is present. Failing to see file 49 on that page leaves open whether it is on page two.

## Coverage and provenance

| Split | Rows | Distinct groups of three | Purpose |
|---|---:|---:|---|
| Training | 762 | 254 | Eight workflows including calendar, sharing, files, help desk, spreadsheets, packing, directories, and exports |
| Development | 90 | 30 | Tune and inspect on library loans and room bookings |
| Test | 135 | 45 | Final comparison on software releases, warehouse transfers, and newsletters |
| Challenge | 24 | 8 | Separately written case files, including unit conversion, a cancelled sale and incomplete inspections |

Each split contains equal numbers of the three verdicts. The 720 generated training examples vary IDs, goal values, readback formats, agent confidence, record order, and evidence quality. Another 42 training examples are individually specified questions built around fourteen evidence packets. The challenge has eight new packets, each with three tickets about the same records. No workflow or exact prompt crosses splits. The generator uses shared writing patterns in the main splits. All 1,011 rows represent 337 correlated groups, not independent incidents. A score on these fictional cases does not establish accuracy on live agent work. The answers were generated or authored for this release, with no independent human annotation.

The file `split_summary.json` contains the counts and workflow names. Rebuild all data using Python 3 from this directory.

```bash
python source/build.py
```

## Score a run

Save one JSON object per prediction, with the same ID as its prompt. Extract the final answer into top-level fields. For an unparsable response, save that ID with a null verdict so it remains in the denominator. Example shape:

```json
{"id":"<id from the prompt>","verdict":"unverified","evidence":["L2"],"reason":"The only readback was taken before the update."}
```

```bash
python score.py eval/dev/answers.jsonl dev_predictions.jsonl
```

The scorer reports accuracy, correctly recognized completions, false completions among all incomplete or unverified cases, and how often all three related questions are correct. It also checks the verdict and the exact set of cited lines against the reference. The evidence metric is deliberately strict. Review the free-text explanation and plausible alternative citations by hand. Missing predictions count against accuracy. Compare the missing rate alongside the false-complete rate.

## An inexpensive classifier baseline

`classifier_baseline.py` fits TF-IDF word unigrams and bigrams with logistic regression on the training split. It predicts a verdict only. Run `python classifier_baseline.py` with scikit-learn installed. The included `dev_baseline.json` records the measured development outcome: 54 of 90 correct, 30 false completions out of 60 non-complete cases, and 30 of 30 actual completions recognized. No Gemma training, inference or performance result is included.

## Experiment with direct and thinking modes

Use verdict data to measure **when extra reasoning pays off**. The same correct verdict can be easy for one checkpoint and difficult for another.

1. Pick a checkpoint that supports both modes. Freeze the checkpoint and run it with thinking off and on against `routing_inputs/train/prompts.jsonl`. Keep decoding settings fixed except for the mode and its token budget. For each run collect final predictions in the format above, total input and output tokens including thinking, and wall-clock latency. Log any failures. If the verifier has already been tuned on these tickets, generate out-of-fold predictions grouped by packet or use fresh disjoint training cases to derive route labels.
2. Run `python build_route_labels.py direct_predictions.jsonl thinking_predictions.jsonl route_train.jsonl`. This creates a second Halo SFT file. The script labels a ticket `direct` when the direct pass gets both verdict and citations right. It assigns `review` when only thinking succeeds, and counts and excludes double failures. It assumes direct is cheaper. Verify that assumption on the target runtime. Manually inspect borderline citations and repeated runs before treating labels as stable. If thinking rescues very few cases, the observed benefit may be too small to warrant training a router.
3. Fine-tune a small separate gate on `route_train.jsonl` or train a separate gate adapter. A serving wrapper uses its output to select the mode on the verifier. This experiment learns a per-ticket decision. It needs no changes to Gemma's internal expert allocation.
4. Compare **always direct**, **always thinking**, the **learned gate**, and a **random gate at the same escalation rate**. Evaluate on exactly the same unseen inputs. Report accuracy and false completions alongside average total tokens, end-to-end latency including the gate, and the fraction sent for review. A checked final result on the wrong target may call for a fresh read. Reasoning alone cannot supply missing observations.

These files contain verdict labels. Route labels require measured paired predictions. Only the lightweight text classifier was run while creating this package.
