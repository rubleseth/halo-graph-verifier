"""Derive route labels from two measured runs on the supplied training inputs."""
import argparse
import json
from collections import Counter
from pathlib import Path

from score import matches, read_by_id

ROOT = Path(__file__).resolve().parent
ROUTE_RULE = ("Choose the cheaper direct mode if it can judge this case reliably. Choose review if extended "
              "reasoning is needed to judge it reliably. Reply with exactly direct or review.\n\n")


def build_routes(fast_path, slow_path, out_path):
    directory = ROOT / "routing_inputs/train"
    prompts = read_by_id(directory / "prompts.jsonl")
    gold = read_by_id(directory / "answers.jsonl")
    fast, slow = read_by_id(fast_path), read_by_id(slow_path)
    if not (gold.keys() == prompts.keys() == fast.keys() == slow.keys()):
        raise ValueError("Provide paired predictions for every training input ID and only those IDs.")
    rows, counts = [], Counter()
    for ident, target in gold.items():
        _, fast_correct = matches(fast[ident], target)
        _, slow_correct = matches(slow[ident], target)
        if not fast_correct and not slow_correct:
            counts["both_failed_excluded"] += 1
            continue
        route = "direct" if fast_correct else "review"
        counts[route] += 1
        # Remove the verifier's output-format instruction; keep only the ticket and evidence.
        ticket = prompts[ident]["prompt"][0]["content"].split("\n\nTicket\n", 1)[1]
        rows.append({"prompt": [{"role": "user", "content": ROUTE_RULE + "Ticket\n" + ticket},
                                {"role": "assistant", "content": route}]})
    with Path(out_path).open("x", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    return counts


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("direct_predictions")
    p.add_argument("thinking_predictions")
    p.add_argument("output_jsonl")
    args = p.parse_args()
    print(json.dumps(build_routes(args.direct_predictions, args.thinking_predictions, args.output_jsonl), indent=2))
