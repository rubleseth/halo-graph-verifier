"""Rebuild the synthetic corpus using Python's standard library."""
import csv
import hashlib
import json
import random
from collections import Counter
from pathlib import Path

from packets import CHALLENGE_PACKETS, TRAIN_PACKETS
from workflows import SPLITS, WORKFLOWS

ROOT = Path(__file__).resolve().parents[1]
LABELS = ("complete", "incomplete", "unverified")
RULE = (
    "Review the ticket using only the numbered records. Judge the final state. "
    "Use complete if every requested condition is confirmed, incomplete if reliable final evidence contradicts any condition, "
    "and unverified otherwise. An agent's claim or an accepted write alone cannot establish the end state. "
    "Return JSON with verdict, evidence (an array of line IDs such as L2), and reason (one short sentence). "
    "Cite the smallest set of records that establishes completion, demonstrates a contradiction, or identifies the evidence gap."
)
NOTES = [
    "Agent handoff: This is done; I checked it.", "Agent handoff: I am unsure whether the changes took.",
    "Agent handoff: Work submitted for review.", "Agent handoff: All requested items are in place.",
    "Agent handoff: I would like a second look.", "Agent handoff: Closing out this run.",
]


def rng_for(key):
    return random.Random(int(hashlib.sha256(key.encode()).hexdigest()[:16], 16))


def make_id(key):
    return hashlib.sha256(("ticket-review-v1/" + key).encode()).hexdigest()[:12]


def make_row(key, group, workflow, ticket, lines, answer):
    assert all(0 < int(ref[1:]) <= len(lines) for ref in answer["evidence"])
    log = "\n".join(f"L{i} | {line}" for i, line in enumerate(lines, start=1))
    question = f"{RULE}\n\nTicket\n{ticket}\n\nRecords\n{log}"
    return {"id": make_id(key), "group": make_id(group), "workflow": workflow,
            "question": question, "ticket": ticket, "log": log, "answer": answer}


def observation(service, ident, field, value, style):
    forms = [
        f"{service} | final committed snapshot | key={ident} | {field}={value}",
        f"After the run, {service} read back {field} for {ident} as '{value}'.",
        f"Closing extract from {service}, record {ident}: {field} -> {value}.",
        f"{service} final lookup returned " + json.dumps({"key": ident, field: value}),
        f"At sign-off, {service} lists {ident} with '{value}' in the {field} field.",
    ]
    return forms[style % len(forms)]


def gap(service, ident, other, field, visible, style, kind):
    if kind == 0:
        return (observation(service, other, field, visible, style),
                f"The {field} reading is for {other}; the ticket specifies {ident}.")
    if kind == 1:
        return (f"{service} cached snapshot for {ident}, taken before the update: {field}={visible}.",
                f"The only recorded {field} value for {ident} predates the update.")
    if kind == 2:
        return (f"Change preview on {service}, {ident}: {field}={visible} (simulation).",
                f"The displayed {field} value comes from a simulation.")
    if kind == 3:
        return (f"Readback for {ident} from {service}: {field} was omitted from this projection.",
                f"The readback omits {field} for {ident}.")
    if kind == 4:
        return (f"Write payload logged by {service}: set {field}={visible} on {ident}; response 202.",
                f"The {field} entry is a write receipt, with no final reading for {ident}.")
    return (f"{service} export for {ident}, {field}: lookup timed out before any value was received.",
            f"The {field} lookup for {ident} returned no value.")


def make_triplet(split, workflow, group_no):
    group = f"{split}/{workflow}/{group_no}"
    rng = rng_for(group)
    prefix, service, *rest = WORKFLOWS[workflow]
    *specs, ticket_text = rest
    ident = f"{prefix.upper()}-{make_id(group)[:6].upper()}"
    other = ident + "-B"
    fields, goals, alternatives = [], [], []
    for spec in specs:
        field, *choices = spec
        goal, alt = rng.choice(choices)
        if rng.randrange(2) and field != "active events under the booking key":
            goal, alt = alt, goal
        fields.append(field)
        goals.append(goal)
        alternatives.append(alt)
    ticket = rng.choice(ticket_text).format(id=ident, a=goals[0], b=goals[1])
    decisive = group_no % 2
    other_slot = 1 - decisive
    styles = [rng.randrange(5), rng.randrange(5)]
    uncertain = [gap(service, ident, other, field, rng.choice((goals[i], alternatives[i])), styles[i],
                     (group_no // 2 + i) % 6) for i, field in enumerate(fields)]
    claim = rng.choice(NOTES)
    receipt = rng.choice([f"Job history for {ident}: change accepted for processing.",
                          f"Request {ident}: service returned a tracking number.",
                          f"Runner: finished submitting the requested edits for {ident}."])
    prior = rng.choice([f"Opening snapshot, before this job: {fields[decisive]}={alternatives[decisive]} on {ident}.",
                        f"Opening snapshot, before this job: {fields[decisive]}={goals[decisive]} on {ident}.",
                        f"Worker summary: one retry during the update to {ident}."])
    extras = [claim, receipt, prior]
    if group_no % 3 == 1:
        extras.append(f"Service monitor: {service} responded to its health check.")
    order = list(range(len(extras) + 2))
    rng.shuffle(order)
    refs = [f"L{order.index(i) + 1}" for i in range(2)]
    result = []
    for label in LABELS:
        readings = [observation(service, ident, fields[i], goals[i], styles[i]) for i in range(2)]
        if label == "complete":
            evidence = refs.copy()
            reason = f"The closing records for {ident} show {fields[0]}={goals[0]} and {fields[1]}={goals[1]}."
        elif label == "incomplete":
            readings[decisive] = observation(service, ident, fields[decisive], alternatives[decisive], styles[decisive])
            if group_no % 4 == 3:
                readings[other_slot] = uncertain[other_slot][0]
            evidence = [refs[decisive]]
            reason = f"The final {fields[decisive]} for {ident} is {alternatives[decisive]}; the ticket requires {goals[decisive]}."
        else:
            readings[decisive], reason = uncertain[decisive]
            evidence = [refs[decisive]]
        sequence = readings + extras
        lines = [sequence[i] for i in order]
        answer = {"verdict": label, "evidence": sorted(evidence, key=lambda x: int(x[1:])), "reason": reason}
        result.append(make_row(group + "/" + label, group, workflow, ticket, lines, answer))
    return result


def from_packets(split, packets):
    rows = []
    for index, (workflow, lines, cases) in enumerate(packets):
        group = f"{split}/packet/{index}"
        for ticket, label, refs, reason in cases:
            answer = {"verdict": label, "evidence": [f"L{r}" for r in refs], "reason": reason}
            rows.append(make_row(group + "/" + label, group, workflow, ticket, lines, answer))
    return rows


def write_jsonl(path, records):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")


def main():
    splits = {split: [item for workflow in workflows for n in range(count)
                      for item in make_triplet(split, workflow, n)]
              for split, (count, workflows) in SPLITS.items()}
    splits["train"].extend(from_packets("train", TRAIN_PACKETS))
    splits["challenge"] = from_packets("challenge", CHALLENGE_PACKETS)
    stats = {}
    seen_ids, seen_prompts, seen_workflows = set(), set(), set()
    for split, rows in splits.items():
        rng_for(split).shuffle(rows)
        workflows = {row["workflow"] for row in rows}
        assert not seen_workflows.intersection(workflows)
        seen_workflows.update(workflows)
        for row in rows:
            assert row["id"] not in seen_ids and row["question"] not in seen_prompts
            seen_ids.add(row["id"])
            seen_prompts.add(row["question"])
        counts = Counter(row["answer"]["verdict"] for row in rows)
        assert len(set(counts.values())) == 1 and set(counts) == set(LABELS)
        stats[split] = {"examples": len(rows), "groups": len({r["group"] for r in rows}),
                        "verdicts": dict(sorted(counts.items())), "workflows": sorted(workflows)}
        if split == "train":
            write_jsonl(ROOT / "data/train.jsonl",
                        ({"prompt": [{"role": "user", "content": r["question"]},
                                     {"role": "assistant", "content": json.dumps(r["answer"], ensure_ascii=False)}]}
                         for r in rows))
        base = ROOT / ("routing_inputs" if split == "train" else "eval") / split
        write_jsonl(base / "prompts.jsonl", ({"id": r["id"], "prompt": [{"role": "user", "content": r["question"]}]}
                                              for r in rows))
        write_jsonl(base / "answers.jsonl", ({"id": r["id"], "group": r["group"], "workflow": r["workflow"],
                                              **r["answer"]} for r in rows))
    preview = ROOT / "first_look.csv"
    with preview.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["ticket", "records", "verdict", "evidence_lines", "reason"])
        for r in make_triplet("train", "calendar", 0) + from_packets("train", TRAIN_PACKETS[:2]):
            a = r["answer"]
            writer.writerow([r["ticket"], r["log"], a["verdict"], ", ".join(a["evidence"]), a["reason"]])
    (ROOT / "split_summary.json").write_text(json.dumps(stats, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v["examples"] for k, v in stats.items()}))


if __name__ == "__main__":
    main()
