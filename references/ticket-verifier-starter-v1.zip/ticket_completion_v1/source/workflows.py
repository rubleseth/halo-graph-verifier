"""Fictional workflows. Each has two independently verifiable ticket conditions."""

# The first entry in each choice tuple is the requested value. The generator
# sometimes swaps the two so the same value appears in both outcomes.
WORKFLOWS = {
    "calendar": (
        "event","calendar service",
        ("start day", ("Wednesday", "Thursday"), ("Monday", "Friday"), ("Tuesday", "Saturday")),
        ("active events under the booking key", ("1", "2"), ("1", "3"), ("1", "4")),
        ("Reschedule the existing event {id} to {a}. There should be {b} active event(s) under its booking key.",
         "Close this calendar ticket when event {id} starts on {a} and the active event count for its booking key is {b}.")),
    "folder_share": (
        "share","sharing directory",
        ("external collaborator role", ("reader", "commenter"), ("commenter", "editor"), ("reader", "editor")),
        ("public link", ("disabled", "enabled"), ("disabled", "enabled")),
        ("For share {id}, set the external collaborator role to {a} and leave the public link {b}.",
         "The handoff for share {id} specifies role {a} for the external collaborator and public link {b}.")),
    "file_move": (
        "file","file catalog",
        ("current folder", ("Editorial", "Design"), ("Exports", "Uploads"), ("Revised", "Intake")),
        ("retained revisions", ("4", "3"), ("7", "6"), ("2", "1")),
        ("Move file {id} into {a}. The finished file must have exactly {b} retained revisions.",
         "For file {id}, I need the current folder to be {a} with {b} revisions retained.")),
    "helpdesk": (
        "case","help desk",
        ("assigned queue", ("Billing", "Returns"), ("Bookings", "Dispatch"), ("Events", "Sales")),
        ("priority", ("normal", "urgent"), ("low", "normal"), ("urgent", "low")),
        ("Route case {id} into {a} at {b} priority.",
         "Please make sure case {id} shows {a} as its assigned queue and {b} as its priority.")),
    "spreadsheet": (
        "sheet","worksheet store",
        ("total cell formula", ("=SUM(B2:B12)", "=SUM(B2:B11)"), ("=SUM(D5:D18)", "=SUM(D6:D18)")),
        ("monthly tab count", ("12", "11"), ("12", "13"), ("6", "5")),
        ("On sheet {id}, store the literal formula {a} in the total cell and leave exactly {b} monthly tabs.",
         "I will accept sheet {id} when the total cell contains {a} and the monthly tab count is {b}.")),
    "pack_order": (
        "picklist","packing register",
        ("packed units", ("6", "5"), ("12", "14"), ("20", "18")),
        ("printed insert", ("spring guide", "winter guide"), ("blue card", "green card"), ("care guide", "returns guide")),
        ("For picklist {id}, pack exactly {a} units and include the printed {b}.",
         "Picklist {id} calls for {a} units in the parcel with a {b} as the printed insert.")),
    "directory": (
        "entry","public directory",
        ("listed counter", ("North", "West"), ("East", "South"), ("Atrium", "Annex")),
        ("closing time", ("17:30", "17:00"), ("18:00", "16:00"), ("15:15", "15:45")),
        ("Update directory entry {id} so the counter is {a} and the closing time is {b}.",
         "Publish {a} as the listed counter and {b} as the closing time on entry {id}.")),
    "report_export": (
        "report","export catalog",
        ("stored format", ("CSV", "TSV"), ("XLSX", "CSV"), ("JSONL", "JSON")),
        ("data row count", ("120", "119"), ("64", "65"), ("200", "198")),
        ("Store report {id} in {a} format with exactly {b} data rows, excluding headers.",
         "For report {id}, the stored format should be {a} and the count excluding headers should be {b}.")),
    "library_loan": (
        "loan","circulation desk",
        ("due date", ("June 14", "June 21"), ("May 03", "May 13"), ("July 12", "July 19")),
        ("renewals remaining", ("1", "0"), ("2", "1"), ("3", "2")),
        ("Set loan {id} due on {a} with {b} renewals remaining.",
         "The circulation record for loan {id} needs a due date of {a} and a remaining renewal count of {b}.")),
    "room_booking": (
        "booking","venue ledger",
        ("booked room", ("Opal", "Quartz"), ("Oak", "Elm"), ("Cedar", "Maple")),
        ("reserved seats", ("32", "23"), ("18", "16"), ("25", "24")),
        ("Put booking {id} in room {a} and reserve exactly {b} seats.",
         "This booking ({id}) is ready when the venue lists room {a} and {b} seats.")),
    "release": (
        "release","deployment inventory",
        ("live version", ("4.12.1", "4.12.0"), ("3.10.0", "3.1.0"), ("2.8.4", "2.8.5")),
        ("production traffic percent", ("100", "10"), ("50", "5"), ("25", "20")),
        ("Release {id} should serve version {a} with {b} percent of production traffic.",
         "For release {id}, production must show live version {a} and traffic share {b} percent.")),
    "inventory": (
        "transfer","warehouse ledger",
        ("destination bin", ("C-04", "C-40"), ("W-12", "W-21"), ("A-10", "A-01")),
        ("units received", ("18", "17"), ("30", "3"), ("40", "42")),
        ("Receive transfer {id} into bin {a} and record exactly {b} units received.",
         "The target warehouse state for transfer {id} is {a} for the bin and {b} for units received.")),
    "newsletter": (
        "issue","publication desk",
        ("audience edition", ("Weekend", "Weekday"), ("Local", "Regional"), ("Morning", "Evening")),
        ("delivery mode", ("digest", "individual"), ("individual", "digest")),
        ("Set newsletter issue {id} to the {a} edition using {b} delivery.",
         "For issue {id}, use the {a} audience edition with delivery mode {b}.")),
}

SPLITS = {
    "train": (30, ["calendar", "folder_share", "file_move", "helpdesk", "spreadsheet", "pack_order", "directory", "report_export"]),
    "dev": (15, ["library_loan", "room_booking"]),
    "test": (15, ["release", "inventory", "newsletter"]),
}
