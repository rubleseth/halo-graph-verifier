"""Authored, fixed evidence packets. The same evidence backs three different tickets.

Case tuple order: requested end state, verdict, minimal source line numbers, explanation.
"""

TRAIN_PACKETS = [
    ("calendar", [
        "Agent note: I moved both sessions to the small room.",
        "Final venue calendar for Series 52: Monday session room Birch; Tuesday session room Ash.",
        "Public print view has no field for seating capacity."], [
        ("Move Monday's Series 52 session to Birch.", "complete", [2], "The final calendar places the Monday session in Birch."),
        ("Move Tuesday's Series 52 session to Birch.", "incomplete", [2], "The final calendar places Tuesday in Ash."),
        ("Ensure Birch has at least 20 seats for Monday's session.", "unverified", [3], "The available view leaves room capacity unknown.")]),
    ("folder_share", [
        "Change receipt: batch 38 processed.",
        "Final shared-folder audit for Wren: active collaborators are Kai (editor) and Eli (reader). This list includes all collaborators.",
        "The audit export omits link-sharing settings."], [
        ("Give Kai edit access to Wren.", "complete", [2], "Kai appears as an editor in the final audit."),
        ("Remove Eli from Wren.", "incomplete", [2], "Eli is still an active reader."),
        ("Disable Wren's public sharing link.", "unverified", [3], "The audit excludes the link-sharing setting.")]),
    ("file_move", [
        "File catalog, final: asset 318 is in Drawings; it retains versions 1, 2 and 3.",
        "A storage-cost report will publish next month.",
        "Catalog note: duplicate-file scan skipped for the rest of the drive."], [
        ("Put asset 318 in Drawings and retain its three versions.", "complete", [1], "The catalog confirms Drawings and enumerates three versions."),
        ("Put asset 318 in Drawings and retain four versions.", "incomplete", [1], "The catalog enumerates only three versions."),
        ("Ensure the drive contains just one copy of asset 318's contents.", "unverified", [3], "The rest of the drive was never scanned for duplicates.")]),
    ("helpdesk", [
        "At 09:12 the customer said the urgency might change.",
        "10:07 final case register, case 134: priority high; assigned queue Returns.",
        "Case register export excludes customer notification history."], [
        ("Assign case 134 to Returns at high priority.", "complete", [2], "The register confirms both the queue and the priority."),
        ("Assign case 134 to Returns at normal priority.", "incomplete", [2], "The register records high priority."),
        ("Notify the customer about case 134's transfer.", "unverified", [3], "The export supplies no notification history.")]),
    ("spreadsheet", [
        "Workbook G, saved copy: total 62. The export contains calculated values only.",
        "Independent recount of the saved workbook: 31 detail rows, header excluded.",
        "Agent: formula and formatting look great."], [
        ("Deliver workbook G with 31 detail rows.", "complete", [2], "The saved copy has exactly 31 detail rows."),
        ("Deliver workbook G showing a total of 63.", "incomplete", [1], "The saved total is 62."),
        ("Make the saved total cell a formula rather than a literal value.", "unverified", [1], "A values-only export cannot distinguish a formula from a literal.")]),
    ("pack_order", [
        "Parcel desk, sealed box 661: packed units 9; printed insert 'winter guide'.",
        "Carrier log for 661 stops at label creation; no pickup scan.",
        "Shift handoff: probably already on the truck."], [
        ("Seal box 661 with nine units and a winter guide.", "complete", [1], "The sealed-box record verifies the count and insert."),
        ("Seal box 661 with nine units and a spring guide.", "incomplete", [1], "The sealed-box record lists the winter guide."),
        ("Have the carrier pick up box 661.", "unverified", [2], "The carrier trail ends at label creation.")]),
    ("directory", [
        "Public listing at close, kiosk K9: counter Atrium, hours 09:00–16:30.",
        "The kiosk's paper sign was outside the scope of the inspection.",
        "Publisher: revised hours are out."], [
        ("Publish 16:30 as the closing time on K9's online listing.", "complete", [1], "The public listing shows a 16:30 close."),
        ("Publish 09:30 as the opening time on K9's online listing.", "incomplete", [1], "The public listing shows a 09:00 opening."),
        ("Replace K9's paper sign with the revised hours.", "unverified", [2], "The inspection excluded the physical sign.")]),
    ("report_export", [
        "Saved collection M: manifest lists only north.csv (14 rows) and south.csv (16 rows). Header lines excluded.",
        "The manifest records filenames and counts only; checksums were never collected.",
        "Operator: all checks passed."], [
        ("Export 30 data rows across collection M.", "complete", [1], "The two files contain 14 + 16 = 30 rows."),
        ("Export 31 data rows across collection M.", "incomplete", [1], "The manifest accounts for only 30 rows."),
        ("Verify that north.csv matches the reference checksum.", "unverified", [2], "The manifest contains no checksum to compare.")]),
]

CHALLENGE_PACKETS = [
    ("museum_labels", [
        "Printer: job S87 accepted, 16 labels requested.",
        "Closing inspection, wall S: all 16 mounting positions counted. Fifteen contain a Spanish label. The last contains an English label.",
        "The inspection sheet records language and position only."], [
        ("Install Spanish labels at at least fifteen positions on wall S.", "complete", [2], "The inspection counted fifteen Spanish labels."),
        ("Install Spanish labels at every position on wall S.", "incomplete", [2], "One of the sixteen positions has an English label."),
        ("Install the approved Spanish translation, with the exact approved punctuation, at fifteen positions on wall S.", "unverified", [3], "The inspection did not record the text or punctuation.")]),
    ("race_results", [
        "Finish-line display at noon: Juno, 12:43 (provisional).",
        "Official closing results: Juno 12:41 after a timing correction. This is the published finish time.",
        "Copy made for this review includes finish times only; the split-time page was not copied."], [
        ("Publish Juno's corrected finish as 12:41.", "complete", [2], "The official closing results publish 12:41."),
        ("Publish Juno's finish as 12:43.", "incomplete", [2], "The closing results supersede the provisional display and give 12:41."),
        ("Publish Juno's halfway split as 06:15.", "unverified", [3], "The review copy omits the page with split times.")]),
    ("print_run", [
        "Batch P: final signed packing slips list Carton A with 72 programs and Carton B with 48. These are all cartons in the batch.",
        "Both slips count bound programs only; neither includes page counts.",
        "Press operator's note: I was aiming for 125."], [
        ("Pack exactly 120 bound programs in batch P.", "complete", [1], "The complete slips account for 72 + 48 = 120 programs."),
        ("Pack at least 121 bound programs in batch P.", "incomplete", [1], "The complete slips total 120, below 121."),
        ("Bind at least 32 pages into each program in batch P.", "unverified", [2], "The slips count programs but omit page counts.")]),
    ("audio_master", [
        "Studio logged a successful export of master R.",
        "Final decode of R: channel 1 contains voice; channel 2 contains voice.",
        "The device wrote 'calibration expired; loudness measurement unavailable' in its meter log."], [
        ("Deliver master R with voice on both channels.", "complete", [2], "Decoding found voice on both channels."),
        ("Deliver master R with voice on channel 1 and silence on channel 2.", "incomplete", [2], "The final decode found voice on channel 2."),
        ("Deliver master R at an integrated loudness of minus 16 LUFS.", "unverified", [3], "The meter returned no usable loudness measurement.")]),
    ("theater_seating", [
        "House manager: Saturday evening should be ready.",
        "Final evening seating chart for Saturday, row J: aisle seats J1 and J12 blocked; intermediate seats J2 through J11 available.",
        "The chart for Saturday's matinee was not in the packet."], [
        ("Block both row J aisle seats for Saturday evening.", "complete", [2], "The evening chart shows both aisle seats blocked."),
        ("Block row J in its entirety for Saturday evening.", "incomplete", [2], "Ten intermediate seats remain available."),
        ("Block both row J aisle seats for Saturday's matinee.", "unverified", [3], "The matinee chart is missing.")]),
    ("bakery_delivery", [
        "A loading-bay photo shows six trays before departure.",
        "At delivery close, the cafe signed for five trays with eight rolls per tray. The receipt covers the full delivery.",
        "Cafe copy: the signature box is legible, but the field for arrival time is blank."], [
        ("Deliver exactly forty rolls to the cafe.", "complete", [2], "The cafe received five trays of eight rolls, totaling forty."),
        ("Deliver six trays to the cafe.", "incomplete", [2], "The cafe signed for five trays on the full delivery receipt."),
        ("Deliver the rolls to the cafe before 08:00.", "unverified", [3], "The delivery receipt leaves the arrival time blank.")]),
]

TRAIN_PACKETS += [
    ("calendar", [
        "16:04 calendar state, booking 411: the original event starts at 15:30.",
        "16:07 transaction 99 moved the original to 17:00.",
        "16:09 transaction 99 was rolled back; the calendar's closing read shows the original at 15:30.",
        "The closing read was by event ID; other events were outside the query."], [
        ("Keep booking 411's original event at 15:30.", "complete", [3], "The closing read confirms 15:30 after the rollback."),
        ("Move booking 411's original event to 17:00.", "incomplete", [3], "The rollback restored the original start time of 15:30."),
        ("Make sure no other event exists for booking 411.", "unverified", [4], "Looking up one event ID cannot rule out another event.")]),
    ("helpdesk", [
        "11:00 batch job marked finished.",
        "Final queue membership, complete list for K9: Routing and Accounts.",
        "Current staffing list for K9: Kai, Mika, Noor. Staff roles are stored separately.",
        "Agent note: customer says the change looks fine."], [
        ("Give K9 to Accounts and put Mika on its staff list.", "complete", [2, 3], "The queue list includes Accounts and the staffing list includes Mika."),
        ("Give K9 exclusively to Accounts.", "incomplete", [2], "K9 is also assigned to Routing."),
        ("Make Mika the lead on K9.", "unverified", [3], "The staff list includes Mika without showing the lead role.")]),
    ("pack_order", [
        "Final signed count for order 23: 10 blue notebooks.",
        "Final signed count for the same order: 12 green notebooks. The two signed counts cover all notebooks packed.",
        "Warehouse note: packing requested by email.",
        "Inspection sampled the covers only; it did not open the notebooks."], [
        ("Pack 22 notebooks in order 23.", "complete", [1, 2], "The two final counts total 22 notebooks."),
        ("Pack 25 notebooks in order 23.", "incomplete", [1, 2], "The complete breakdown totals 22, short of 25."),
        ("Pack only lined notebooks in order 23.", "unverified", [4], "The inspection omitted the interior pages.")]),
    ("file_move", [
        "Folder browser shows page 1 of 2 for Archive after the move. Item 44 is visible; page 2 was not retrieved.",
        "Separate final item lookup: file 44 has name 'budget-final'.",
        "Agent: old file 49 is gone."], [
        ("Keep file 44 in Archive under the name budget-final.", "complete", [1, 2], "The folder page includes file 44 and the item lookup confirms the name."),
        ("Remove file 44 from Archive.", "incomplete", [1], "File 44 appears on the returned page of Archive."),
        ("Remove file 49 from Archive.", "unverified", [1], "The folder listing has an unread page that may contain file 49.")]),
    ("report_export", [
        "Final export inspection: J.csv is 4096 bytes.",
        "Final export inspection: K.csv is 6144 bytes. The manifest lists only J.csv and K.csv.",
        "The inspector did not open either file; data row counts were not collected."], [
        ("Deliver exactly 10 KiB of files in this export (1 KiB = 1024 bytes).", "complete", [1, 2], "The two files total 10,240 bytes, exactly 10 KiB."),
        ("Deliver less than 10 KiB of files in this export (1 KiB = 1024 bytes).", "incomplete", [1, 2], "The files total exactly 10 KiB, exceeding the strict less-than limit."),
        ("Deliver 100 data rows across the export.", "unverified", [3], "The inspector never counted the rows.")]),
    ("spreadsheet", [
        "Official workbook P version history: r5 saved most recently.",
        "Formula inspector on r4: cell A1 =SUM(B2:B8).",
        "Formula inspector on r5: cell A1 =SUM(B2:B9).",
        "Inspector reads saved formulas only and does not recalculate numeric results."], [
        ("Save =SUM(B2:B9) as A1's formula in the latest revision of P.", "complete", [1, 3], "Revision r5 is current and its A1 formula includes B9."),
        ("Save =SUM(B2:B8) as A1's formula in the latest revision of P.", "incomplete", [1, 3], "The latest revision is r5 and its formula includes B9."),
        ("Make A1's numeric result 42 in P.", "unverified", [4], "The formula inspector does not compute the numeric result.")]),
]

CHALLENGE_PACKETS += [
    ("ticket_sales", [
        "19:00 box office issued receipt for sale 312. Seats sold: H11 and H12.",
        "19:04 cancellation: sale 312 voided in full.",
        "19:07 final ledger read: replacement sale 319 has one seat, H12. There are no other active sales for this customer.",
        "Fulfilment audit export excludes delivery receipts."], [
        ("Leave the customer with only H12 booked.", "complete", [3], "The final ledger records just H12 for the customer."),
        ("Leave the customer with H11 and H12 booked.", "incomplete", [3], "The final ledger records only H12."),
        ("Deliver the replacement ticket to the customer by email.", "unverified", [4], "The export excludes delivery receipts.")]),
    ("fabric_cut", [
        "Final roll inspection, order V: red length 2.4 m.",
        "Final roll inspection, order V: blue length 60 cm. The order contains only red and blue fabric.",
        "Inspection method: lengths were measured after cutting; widths were not recorded."], [
        ("Supply exactly 3 metres of fabric in order V.", "complete", [1, 2], "2.4 metres plus 0.6 metres equals 3 metres."),
        ("Supply more than 3 metres of fabric in order V.", "incomplete", [1, 2], "The two lengths total exactly 3 metres."),
        ("Use only fabric at least a metre wide for order V.", "unverified", [3], "The inspection measured length and omitted width.")]),
]
