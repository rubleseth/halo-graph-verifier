"""Score a complete run. Missing cases stay in denominators. Standard library only."""
import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

LABELS = ("complete", "incomplete", "unverified")


def read_by_id(path):
    rows = {}
    with Path(path).open(encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            row = json.loads(line)
            ident = row["id"]
            if ident in rows:
                raise ValueError(f"{path}:{line_no}: duplicate id {ident}")
            rows[ident] = row
    return rows


def matches(pred, gold):
    cited = pred.get("evidence")
    verdict_ok = pred.get("verdict") == gold["verdict"]
    cites_ok = (isinstance(cited, list) and all(isinstance(i, str) for i in cited)
                and len(cited) == len(set(cited)) and set(cited) == set(gold["evidence"]))
    return verdict_ok, verdict_ok and cites_ok


def rate(numerator, denominator):
    return {"count": numerator, "out_of": denominator, "rate": round(numerator / denominator, 4) if denominator else None}


def score(gold, preds):
    if not gold:
        raise ValueError("Empty answer key")
    extra = preds.keys() - gold.keys()
    if extra:
        raise ValueError(f"Predictions include {len(extra)} unknown IDs")
    matrix = {label: Counter() for label in LABELS}
    all_labels = Counter()
    groups = defaultdict(list)
    good = grounded = false_complete = invalid = missed = 0
    for ident, target in gold.items():
        prediction = preds.get(ident, {})
        predicted = prediction.get("verdict")
        actual = target["verdict"]
        all_labels[actual] += 1
        if predicted not in LABELS:
            invalid += 1
            predicted = "invalid_or_missing"
        missed += ident not in preds
        matrix[actual][predicted] += 1
        correct, supported = matches(prediction, target)
        good += correct
        grounded += supported
        false_complete += predicted == "complete" and actual != "complete"
        groups[target["group"]].append(correct)
    n = len(gold)
    c = all_labels["complete"]
    return {
        "examples": n, "missing_predictions": missed, "invalid_or_missing_verdicts": invalid,
        "verdict_accuracy": rate(good, n), "verdict_and_exact_citations": rate(grounded, n),
        "false_complete_rate": rate(false_complete, n - c),
        "complete_recall": rate(matrix["complete"]["complete"], c),
        "all_three_verdicts_correct_in_group": rate(sum(all(v) for v in groups.values()), len(groups)),
        "confusion_counts_gold_then_predicted": {k: dict(v) for k, v in matrix.items()},
    }


if __name__ == "__main__":
    cmd = argparse.ArgumentParser(description=__doc__)
    cmd.add_argument("answers")
    cmd.add_argument("predictions")
    args = cmd.parse_args()
    print(json.dumps(score(read_by_id(args.answers), read_by_id(args.predictions)), indent=2))
