"""Fit a word/bigram TF-IDF logistic regression on train and evaluate on development."""
import json
from pathlib import Path

import sklearn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

from score import read_by_id, score

ROOT = Path(__file__).resolve().parent


def ticket_and_log(prompt):
    return prompt.split("\n\nTicket\n", 1)[1]


def main():
    rows = [json.loads(r)["prompt"] for r in (ROOT / "data/train.jsonl").read_text(encoding="utf-8").splitlines()]
    model = make_pipeline(TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True),
                          LogisticRegression(max_iter=300, random_state=42))
    model.fit([ticket_and_log(r[0]["content"]) for r in rows], [json.loads(r[1]["content"])["verdict"] for r in rows])
    prompts = read_by_id(ROOT / "eval/dev/prompts.jsonl")
    labels = model.predict([ticket_and_log(r["prompt"][0]["content"]) for r in prompts.values()])
    predictions = {i: {"verdict": val} for i, val in zip(prompts, labels)}
    result = score(read_by_id(ROOT / "eval/dev/answers.jsonl"), predictions)
    del result["verdict_and_exact_citations"]  # This baseline outputs a class only.
    print(json.dumps({"split": "dev", "sklearn": sklearn.__version__, **result}, indent=2))


if __name__ == "__main__":
    main()
